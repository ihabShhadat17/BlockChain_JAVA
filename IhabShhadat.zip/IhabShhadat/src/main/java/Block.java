import org.apache.commons.codec.digest.DigestUtils;
import java.io.Serializable;
import java.util.Date;
import java.util.concurrent.ConcurrentLinkedQueue;
public class Block implements Serializable {


    private long blockID;
    private long timeStamp;
    private ConcurrentLinkedQueue<Transaction> transactions ;
    private String previousHash;
    private String blockHash;
    private long nonce;
    private int difficulty;



    public Block(long blockID, String previousHash) {
        this.blockID = blockID;
        this.timeStamp = new Date().getTime();
        this.transactions =new ConcurrentLinkedQueue();
        this.previousHash = previousHash;
        this.blockHash=calculateHash();
        this.nonce=0;
        this.difficulty=5;
    }


    public ConcurrentLinkedQueue<Transaction> getTransactions() {
        return transactions;
    }

    public long getBlockID() {
        return blockID;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public String getPreviousHash() {
        return previousHash;
    }

    public long getNonce() {
        return nonce;
    }



    private String calculateHash() {

        return DigestUtils.sha256Hex(previousHash
                +timeStamp
                +blockID
                +nonce
                +transactions.hashCode());
    }



    public boolean addTransaction(Transaction transaction)
    {
        transactions.add(transaction);
        return true;
    }
    public String getBlockHash() {
        return blockHash;
    }

    public long mineBlock() {
        while(!blockHash.substring( 0, difficulty).equals
                ( new String(new char[difficulty]).replace("\0", "0")))
        {
            nonce++;
            blockHash = DigestUtils.sha256Hex( previousHash + blockID + timeStamp + nonce);
        }
        return nonce;
    }


    public boolean mineBlock(long nonce)
    {
        this.nonce=nonce;
        blockHash = DigestUtils.sha256Hex( previousHash + blockID + timeStamp + nonce);
        if(!blockHash.substring( 0, difficulty).equals
                ( new String(new char[difficulty]).replace("\0", "0"))) {
            return false;
        }
        return true;
    }

}