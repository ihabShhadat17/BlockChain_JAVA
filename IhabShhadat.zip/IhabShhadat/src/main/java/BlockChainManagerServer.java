
import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class BlockChainManagerServer {

    private static BlockChain chain=BlockChain.getInstance();

    private static Runnable getBlockChainTask(Socket s) {
        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                try{
                    ObjectOutputStream stream = new ObjectOutputStream(s.getOutputStream());
                    stream.writeObject(chain.getChain());
                    stream.close();
                    s.close();
                } catch (Exception e) {
                }
            }
        };
        return runnable;
    }

    private static Runnable addBlockToBlockChainTask(Socket s) {
        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                try{
                    ObjectInputStream stream = new ObjectInputStream(s.getInputStream());
                    chain.addBlock((ConcurrentLinkedQueue) stream.readObject());
                    stream.close();
                    s.close();
                } catch (Exception e) {
                }
            }
        };
        return runnable;
    }

    public static void main(String arg[]) throws Exception
    {

            ServerSocket socket=new ServerSocket(9922);

            ExecutorService service = Executors.newFixedThreadPool(10);

            ServerSocket socket1=new ServerSocket(9923);
            ExecutorService service1 = Executors.newFixedThreadPool(10);
            Runnable r=new Runnable() {
                @Override
                public void run() {
                    try {
                        while (true)
                        service1.execute(addBlockToBlockChainTask(socket1.accept()));
                    } catch (Exception e) {

                    }
                }
            };

            Runnable r2=new Runnable() {
                @Override
                public void run() {
                    try {
                        while (true)
                        service.execute(getBlockChainTask(socket.accept()));
                    }catch (Exception e)
                    {

                    }
                }
            };
        service.execute(r);
        service1.execute(r2);
    }
}
