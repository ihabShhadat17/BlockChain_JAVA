import javax.crypto.Cipher;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class EncryptDecrypt
{
    private PublicKey publicKey;
    private PrivateKey privateKey;

    EncryptDecrypt(byte[] puk,byte[] prk) {
        try {
            KeyFactory kf = KeyFactory.getInstance("RSA"); // or "EC" or whatever
            publicKey = kf.generatePublic(new X509EncodedKeySpec(puk));
            privateKey = kf.generatePrivate(new PKCS8EncodedKeySpec(prk));

        } catch (Exception e) {
        }
    }

    byte[] Encrypt(String data)
    {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            return cipher.doFinal(data.getBytes());
        }catch (Exception e)
        {
        }
        return null;
    }
    String Decrypt(byte encrypt[])
    {
        try {
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            return new String(cipher.doFinal(encrypt));
        }catch (Exception e)
        {
        }
        return null;
    }

}