import java.util.concurrent.ConcurrentLinkedQueue;

public class TransactionList {

    private ConcurrentLinkedQueue<Transaction> transactions;
    private static TransactionList tl;
    TransactionList()
    {
        transactions=new ConcurrentLinkedQueue();
    }
    public static TransactionList getInstance()
    {
        if(tl==null)
        {
            tl=new TransactionList();
        }
        return tl;
    }
    public void addTransaction(Transaction t)
    {
        transactions.add(t);
    }

    public ConcurrentLinkedQueue<Transaction> getTransactions() {
        ConcurrentLinkedQueue<Transaction> transactionsResult=new ConcurrentLinkedQueue();
        while (transactions.size()!=0)
            transactionsResult.add(transactions.poll());
        return transactionsResult;
    }


}
