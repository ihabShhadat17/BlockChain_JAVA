import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
public class PairGenerator {
    private static Runnable getPairGenerator(Socket socket)
    {
       Runnable runnable=new Runnable() {
           @Override
           public void run() {
               try {
                   ObjectOutputStream stream=new ObjectOutputStream(socket.getOutputStream());
                   RSAKeyPairGenerator generator=new RSAKeyPairGenerator();
                   stream.writeObject(generator.getPrivateKey().getEncoded());
                   stream.writeObject(generator.getPublicKey().getEncoded());
                   stream.flush();
                   stream.close();
                   socket.close();
               } catch (IOException e) {
                   e.printStackTrace();
               }
           }
       } ;
       return runnable;
    }
    public static void main(String[] args) throws IOException {
        ExecutorService executorService = Executors.newFixedThreadPool(2);
        ServerSocket serverSocket=new ServerSocket(9900);
        while(true)
        executorService.execute(getPairGenerator(serverSocket.accept()));
    }
}