import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.*;

public class Interface{

    Map<Integer, String> SmartContract = new HashMap<>();
    public JPanel jpanel;
    private JList list1;
    private JTextPane textPane1;
    private JList list2;
    private JButton button1;
    private JButton addBlockButton;
    private JTextField sensorID;
    private JTextField rangeFrom;
    ConcurrentLinkedDeque<Block> blocks;
    Socket socket;
    ListModel<String> listModel;
    ListModel<String> listModel1;
    Iterator<Block> x;
    public static String[] sensor = {
            "Moisture detection",
            "Equipment monitoring",
            "Access control",
            "Power supply monitoring",
            "CO2 level",
            "Air circulation monitoring",
            "Water pH levels"};
    private void getOnlineNode ()
    {   try {
        socket = new Socket("localHost", 9912);
        ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
        ConcurrentHashMap<Integer, UserNetworkInformation> onlineNode = (ConcurrentHashMap<Integer, UserNetworkInformation>) inputStream.readObject();
        ListModel<String> listModel = new DefaultListModel<>();
        for (Integer user : onlineNode.keySet()) {
            if(onlineNode.get(user).getNodeID()>sensor.length)
            ((DefaultListModel<String>) listModel).addElement(""+onlineNode.get(user).getNodeID());
            else
                ((DefaultListModel<String>) listModel).addElement(""+onlineNode.get(user).getNodeID()+" ("+sensor[onlineNode.get(user).getNodeID()]+")");


        }

        list1.setModel(listModel);
        socket.close();
    }catch (Exception e)
    {

    }
    }

    private Block getBlockChain()
    {
        Block b=null;
        try
        {
            socket = new Socket("localhost", 9922);
            blocks = (ConcurrentLinkedDeque<Block>) new ObjectInputStream(socket.getInputStream()).readObject();
            socket.close();
            listModel1 = new DefaultListModel<>();
            x = blocks.iterator();
            while (x.hasNext()) {
                b=x.next();
                ((DefaultListModel<String>) listModel1).addElement(b.getBlockHash());
            }
            list2.setModel(listModel1);
            list2.notifyAll();

        }catch (Exception e)
        {

        }
        return b;
    }

    ConcurrentLinkedQueue getTransactionList() throws Exception
    {

        Socket s=new Socket("localhost",9956);
        ObjectInputStream stream1=new ObjectInputStream(s.getInputStream());
        ConcurrentLinkedQueue queue=((ConcurrentLinkedQueue)stream1.readObject());
        stream1.close();
        s.close();
        return queue;
    }

    void addBlock(ConcurrentLinkedQueue transactionList)throws Exception
    {
        Socket s=new Socket("localhost",9923);
        ObjectOutputStream stream=new ObjectOutputStream(s.getOutputStream());
        stream.writeObject(transactionList);
        stream.close();
        s.close();
    }

    public Interface() {

        getOnlineNode();
        getBlockChain();
        list2.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {

                Iterator x=blocks.iterator();
                int counter=0;
                Block b=null;
                while (x.hasNext()) {
                    if(counter++==list2.getSelectedIndex())
                        b= (Block)x.next();
                }


                Iterator<Transaction> tI= b.getTransactions().iterator();
                String transactions="transaction: ";
                while (tI.hasNext()) {
                    Transaction t=tI.next();
                    transactions += t.getSender() + "\t" +t.getValue()+"\t"+"\n";
                }
                textPane1.setText("Block ID: "+b.getBlockID()+"\nBlock Hash: "+b.getBlockHash()+"\ncreate Time: "+b.getTimeStamp()+"\nPrevious Hash: "+b.getPreviousHash()+"\n"+transactions+"\nNonce: "+b.getNonce());
            }
        });







        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                EncryptDecrypt decrypt=new EncryptDecrypt(Login.publicKey,Login.privateKey);
                Transaction transaction=new Transaction(344313580,"Sensor Type:"+sensorID.getText()+"\n"+"value:"+rangeFrom.getText(),decrypt.Encrypt("this"));
                SmartContract.put(Integer.parseInt(sensorID.getText().trim()),rangeFrom.getText());

                try{
                    Socket s = new Socket("localhost", 9955);
                    ObjectOutputStream stream = new ObjectOutputStream(s.getOutputStream());
                    stream.writeObject(transaction.getSender());
                    stream.writeObject(transaction.getValue());
                    stream.writeObject(transaction.getSenderSignature());
                    stream.close();
                    s.close();
                }catch (Exception addTransaction)
                {
                    addTransaction.printStackTrace();
                }
            }
        });

        addBlockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                      try{
                          ConcurrentLinkedQueue queue = getTransactionList();
                          addBlock(queue);
                          Block b=getBlockChain();

                          queue=b.getTransactions();
                          Iterator i=queue.iterator();

                          while(i.hasNext())
                          {

                              Transaction t=(Transaction) i.next();
                              String action="";
                              if(SmartContract.containsKey(t.getSender()))
                              {
                                  if(SmartContract.get(t.getSender()).equalsIgnoreCase(t.getValue()))
                                  {
                                      if(t.getSender()==0) {
                                          if (t.getValue().equalsIgnoreCase("Low")) {
                                                action="Moisture changed from Low to Medium";
                                          }
                                          if (t.getValue().equalsIgnoreCase( "Medium"))
                                          {
                                              action="Moisture is Medium  ";
                                          }
                                          if(t.getValue().equalsIgnoreCase("High"))
                                          {

                                              action="Moisture changed from High to Medium";

                                          }
                                      }
                                      else if(t.getSender()==1) {
                                          if (t.getValue().equalsIgnoreCase( "Heating,Disabled")) {
                                            action="fixed";
                                          }
                                          if (t.getValue().equalsIgnoreCase( "lighting,Disabled"))
                                          {
                                              action="fixed";
                                          }
                                          if(t.getValue().equalsIgnoreCase("door lock,Disabled"))
                                          {
                                              action="fixed";
                                          }
                                          if (t.getValue().equalsIgnoreCase( "Heating,Not disabled")) {
                                              action="Nothing Change";
                                          }
                                          if (t.getValue().equalsIgnoreCase("lighting,Not disabled"))
                                          {
                                              action="Nothing Change";
                                          }
                                          if(t.getValue().equalsIgnoreCase("door lock,Not disabled"))
                                          {
                                              action="Nothing Change";

                                          }
                                      }
                                      else if(t.getSender()==2) {
                                          if (t.getValue().equalsIgnoreCase( "Locked")) {
                                            action="Locked";
                                          }
                                          if (t.getValue().equalsIgnoreCase( "unlocked"))
                                          {
                                            action="door locked";
                                          }

                                      }
                                      else if(t.getSender()==3) {
                                          if (t.getValue().equalsIgnoreCase("On")) {
                                            action="Power supply is low";
                                          }
                                          if (t.getValue().equalsIgnoreCase("Off"))
                                          {
                                            action="UPS IS ON";
                                          }

                                      }
                                      else if(t.getSender()==4) {
                                          if (t.getValue().equalsIgnoreCase( "Low")) {
                                              action="Low from Low To Medium";
                                          }
                                          if (t.getValue().equalsIgnoreCase( "Medium"))
                                          {
                                              action="Medium";
                                          }
                                          if(t.getValue().equalsIgnoreCase("High"))
                                          {

                                              action="change from high to Medium ";

                                          }
                                      }
                                      else if(t.getSender()==5) {
                                          if (t.getValue().equalsIgnoreCase( "Low")) {
                                              action="Low from Low To Medium";
                                          }
                                          if (t.getValue().equalsIgnoreCase( "Medium"))
                                          {
                                              action="Medium";
                                          }
                                          if(t.getValue().equalsIgnoreCase("High"))
                                          {

                                              action="change from high to Medium ";

                                          }
                                      }
                                      else if(t.getSender()==6) {
                                          if (t.getValue().equalsIgnoreCase( "Low")) {
                                              action="Low from Low To Medium";
                                          }
                                          if (t.getValue().equalsIgnoreCase("Medium"))
                                          {
                                              action="Medium";
                                          }
                                          if(t.getValue().equalsIgnoreCase("High"))
                                          {

                                              action="change from high to Medium ";

                                          }
                                      }



                                      Socket s=new Socket("192.168.1.113",9901);
                                      ObjectOutputStream os=new ObjectOutputStream( s.getOutputStream());
                                      os.writeObject(action);
                                      os.close();
                                      s.close();
                                      JOptionPane.showMessageDialog(null,action);
                                  }

                              }


                          }


                      }catch (Exception e1)
                      {
                      }

            }
        });
    }

}
