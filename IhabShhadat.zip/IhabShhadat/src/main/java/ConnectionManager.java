import java.util.concurrent.ConcurrentHashMap;

public class ConnectionManager {

    private ConcurrentHashMap <Integer, UserNetworkInformation> onlineNodes;

    private static ConnectionManager connectionManager;

    private ConnectionManager() {
        onlineNodes = new ConcurrentHashMap();
    }

    public static ConnectionManager getInstance() {
        if (connectionManager == null)

            synchronized (ConnectionManager.class) {
                if (connectionManager == null)
                    connectionManager = new ConnectionManager();
            }
        return connectionManager;
    }

    public ConcurrentHashMap<Integer,UserNetworkInformation> getOnlineNodes()
    {
        return onlineNodes;
    }

    public void logInNode(UserNetworkInformation node) {
        onlineNodes.put(node.hashCode(), node);
    }
}