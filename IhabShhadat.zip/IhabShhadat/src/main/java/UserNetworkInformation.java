
import java.io.Serializable;

public class UserNetworkInformation implements Serializable {

    private String hostIP;
    private int port;
    private int NodeID;
    private byte[] publicKey;


    public UserNetworkInformation(int NodeID, byte[] publicKey) {
        this.hostIP = Port.findIp_Address();
        this.port = Port.findAvailableTcpPort();
        this.NodeID = NodeID;
        this.publicKey = publicKey;

    }

    public UserNetworkInformation(String ip,int port,int NodeID, byte[] publicKey) {
        this.hostIP = ip;
        this.port = port;
        this.NodeID = NodeID;
        this.publicKey = publicKey;

    }

    public String getHostIP() {
        return hostIP;
    }
    public int getPort() {
        return port;
    }

    public byte[] getPublicKey() {
        return publicKey;
    }

    public int getNodeID() {
        return NodeID;
    }

    @Override
    public int hashCode() {
        return port*hostIP.hashCode();
    }
}