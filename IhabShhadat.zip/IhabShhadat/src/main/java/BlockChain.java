import java.util.Iterator;
import java.util.concurrent.*;

public class BlockChain
{

   private ConcurrentLinkedDeque<Block> chain;
   private static BlockChain b;

   private BlockChain() {
       chain=new ConcurrentLinkedDeque<>();
       Block b=new Block(chain.size()+1,"0");
       b.mineBlock();
       chain.add(b);
   }

   public static BlockChain getInstance()
    {
        if(b==null)
            b=new BlockChain();
        return b;
    }

   public void addBlock(ConcurrentLinkedQueue t)
   {
       Block block=new Block(chain.size()+1,chain.getLast().getBlockHash());
       Iterator i=t.iterator();
       while (i.hasNext())
       {
           block.addTransaction((Transaction) i.next());
       }
       block.mineBlock();
       chain.add(block);
   }

    public ConcurrentLinkedDeque<Block> getChain() {
        return chain;
    }
}