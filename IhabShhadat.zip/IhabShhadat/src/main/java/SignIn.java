import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;

public class SignIn {
    private JButton SignUp;
    private JPanel panel1;
    private JTextField nodeId;
    private JButton singIn;
    private static JFrame mainFrame;

    private void writeToFile(String path, byte[] key) throws IOException {
        File f = new File(path);
        f.getParentFile().mkdirs();
        ObjectOutputStream fos = new ObjectOutputStream(new FileOutputStream(f));
        fos.writeObject(key);
        fos.flush();
        fos.close();
    }


    public SignIn() {
        SignUp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                Socket keyGenerator=new Socket("localHost",9900);

                ObjectInputStream keys=new ObjectInputStream(keyGenerator.getInputStream());

                byte[]pk=(byte[])keys.readObject();
                byte[]puk=(byte[])keys.readObject();

                nodeId.setText((new String(pk).hashCode()+new String(puk).hashCode())+"");


                writeToFile("RSA/privateKey",pk);
                writeToFile("RSA/publicKey",puk);
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });
        singIn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainFrame.setVisible(false);
                JFrame jFrame=new JFrame("Smart Contract");
                jFrame.setContentPane(new Login().jpanel);
                jFrame.setPreferredSize(new Dimension(400, 300));
                jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                jFrame.pack();
                jFrame.setVisible(true);
            }
        });
    }

    public static void main(String[] args) throws Exception{
            mainFrame = new JFrame("Smart Contract");
            mainFrame.setContentPane(new SignIn().panel1);
            mainFrame.setPreferredSize(new Dimension(400, 300));
            mainFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            mainFrame.pack();
            mainFrame.setVisible(true);
    }
}
