import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TransactionPort {
    private static TransactionList list=TransactionList.getInstance();

    private static Runnable addTransaction(Socket socket)
    {
        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                try {
                    ObjectInputStream is=new ObjectInputStream(socket.getInputStream());
                    Transaction t=new Transaction((int)is.readObject(),(String) is.readObject(),(byte[]) is.readObject());
                    is.close();
                    socket.close();
                    list.addTransaction(t);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } ;
        return runnable;
    }

    private static Runnable getTransactions(Socket socket)
    {
        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                try {
                    ObjectOutputStream s=new ObjectOutputStream(socket.getOutputStream());
                    s.writeObject(list.getTransactions());
                    s.close();
                    socket.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } ;
        return runnable;
    }


    public static void main(String[] args) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    ExecutorService executorService = Executors.newFixedThreadPool(10);
                    ServerSocket serverSocket = new ServerSocket(9955);
                    while (true)
                        executorService.execute(addTransaction(serverSocket.accept()));
                }catch (Exception e)
                {

                }

            }
        }).start();

       new Thread(new Runnable() {
           @Override
           public void run() {
               try {
                   ExecutorService executor = Executors.newFixedThreadPool(10);
                   ServerSocket server = new ServerSocket(9956);
                   while (true)
                       executor.execute(getTransactions(server.accept()));
               }catch (Exception e)
               {

               }

           }
       }).start();

    }
}