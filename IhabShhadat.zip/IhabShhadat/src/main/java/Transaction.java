import java.io.Serializable;
public class Transaction implements Serializable {

    private int sender;
    private byte[] senderSignature;
    private String value ;

    public Transaction( int sender,String value,byte[] senderSignature)  {
        this.sender = sender;
        this.value=value;
        this.senderSignature=senderSignature;
    }

    public int getSender() {
        return sender;
    }

    public String getValue() {
        return value;
    }

    public byte[] getSenderSignature() {
        return senderSignature;
    }

    @Override
    public String toString() {
        return sender+new String(senderSignature)+value;
    }
}
