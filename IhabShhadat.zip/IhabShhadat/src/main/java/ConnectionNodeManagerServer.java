
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConnectionNodeManagerServer{

    private static ConnectionManager manager=ConnectionManager.getInstance();

    private static Runnable getOnLinesNode(Socket node)
    {
        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                try {
                    ObjectOutputStream allOnlineNode = new ObjectOutputStream(node.getOutputStream());
                    allOnlineNode.writeObject(manager.getOnlineNodes());
                    allOnlineNode.close();
                    node.close();
                }catch (Exception e)
                {
                }
            }
        };
        return runnable;

    }

    private static Runnable addNodeToConnectionManager(Socket node)
    {
        Runnable runnable=new Runnable() {
            @Override
            public void run() {
                try {
                    ObjectInputStream addNewNode=new ObjectInputStream(node.getInputStream());

                    UserNetworkInformation p=new UserNetworkInformation((String)addNewNode.readObject(),(int)addNewNode.readObject(),(int)addNewNode.readObject(),(byte[])addNewNode.readObject());
                    manager.logInNode(p);
                    addNewNode.close();
                    node.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };
        return runnable;
    }

    public static void main(String arg[]) throws IOException {

        ExecutorService executorService = Executors.newFixedThreadPool(4);

        ExecutorService service=Executors.newFixedThreadPool(4);

        Runnable onLinesNode=new Runnable() {
            @Override
            public void run() {
                try {
                    ServerSocket socket = new ServerSocket(9912);
                    while (true) {
                        executorService.execute(getOnLinesNode(socket.accept()));
                    }
                }catch (Exception e)
                {
                }
            }
        };

        Runnable newNode=new Runnable() {
            @Override
            public void run() {
                try {
                    ServerSocket socket = new ServerSocket(9911);
                    while (true) {
                        executorService.execute(addNodeToConnectionManager(socket.accept()));
                    }
                }catch (Exception e)
                {
                }
            }
        };

        service.execute(newNode);
        service.execute(onLinesNode);
    }
}