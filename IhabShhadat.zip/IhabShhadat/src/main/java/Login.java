import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.Socket;
import java.util.TimerTask;

public class Login {
    private JButton Login;
    public JPanel jpanel;
    private JTextField textField1;
    public static byte[] privateKey = null;
    public static byte[] publicKey = null;

    public Login() {
        Login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {


                int nodeID = Integer.parseInt(textField1.getText());
                JFileChooser jFileChooser = new JFileChooser();
                jFileChooser.setDialogTitle("Select your Private Key File");

                int result = (int) jFileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = jFileChooser.getSelectedFile();
                    try {

                        ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(selectedFile));
                        privateKey = (byte[]) inputStream.readObject();

                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error Select UR File", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                jFileChooser.setDialogTitle("Select your Public Key File");
                result = (int) jFileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = jFileChooser.getSelectedFile();
                    try {

                        ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(selectedFile));
                        publicKey = (byte[]) inputStream.readObject();

                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "Error Select UR File", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (Integer.parseInt(textField1.getText()) == new String(privateKey).hashCode() + new String(publicKey).hashCode())
                {

                    UserNetworkInformation userNetworkInformation = new UserNetworkInformation(Integer.parseInt(textField1.getText()), publicKey);
                    try
                    {
                        Socket socket = new Socket("localhost", 9911);
                        ObjectOutputStream stream = new ObjectOutputStream(socket.getOutputStream());
                        stream.writeObject(userNetworkInformation.getHostIP());
                        stream.writeObject(userNetworkInformation.getPort());
                        stream.writeObject(userNetworkInformation.getNodeID());
                        stream.writeObject(userNetworkInformation.getPublicKey());

                        stream.flush();
                        stream.close();

                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                    JFrame jFrame=new JFrame("Smart Contract");
                    try {
                        jFrame.setContentPane(new Interface().jpanel);
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }
                    jFrame.setPreferredSize(new Dimension(800, 600));
                    jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
                    jFrame.pack();
                    jFrame.setVisible(true);
                }

            }

        });
    }
}